/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import docwebservices.FileNotFoundException_Exception;
import docwebservices.MalformedURLException_Exception;
import docwebservices.ParseException_Exception;
import javax.swing.table.DefaultTableModel;
import org.json.simple.JSONArray;
import ws.IOException_Exception;

/**
 *
 * @author Nayphilim
 */
public class ShareBrokerClient {
    static String Username;
        public static void main(String[] args) {
        
    }

    public static java.util.List<org.netbeans.xml.schema.shares.Shares> getShareList() {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        return port.getShareList();
    }

    public static void completeTransaction(int arg0, java.lang.String arg1) throws IOException_Exception {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        port.completeTransaction(arg0, arg1);
    }

    public static double getExchangeRateValue(java.lang.String arg0) {
        docwebservices.ConversionRestResourceService service = new docwebservices.ConversionRestResourceService();
        docwebservices.ConversionRestResource port = service.getConversionRestResourcePort();
        return port.getExchangeRateValue(arg0);
    }

    public static void updateCurrencyRates() throws docwebservices.IOException_Exception, MalformedURLException_Exception, ParseException_Exception {
        docwebservices.ConversionRestResourceService service = new docwebservices.ConversionRestResourceService();
        docwebservices.ConversionRestResource port = service.getConversionRestResourcePort();
        port.updateCurrencyRates();
    }

    public static boolean validateUser(java.lang.String arg0) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        return port.validateUser(arg0);
    }
    
    public static void setUsername(String username){
        Username = username;
    }
    
    public static String getUsername(){
        return Username;
    }

    public static String getUserShares(java.lang.String arg0) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        return port.getUserShares(arg0);
    }

    public static void addUserShares(java.lang.String arg0, java.lang.String arg1, int arg2, java.lang.String arg3, double arg4) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        port.addUserShares(arg0, arg1, arg2, arg3, arg4);
    }

    public static void sellShares(java.lang.String arg0, java.lang.String arg1, int arg2, java.lang.String arg3, double arg4) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        port.sellShares(arg0, arg1, arg2, arg3, arg4);
    }

    public static boolean hasStocks(java.lang.String arg0, java.lang.String arg1) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        return port.hasStocks(arg0, arg1);
    }

    public static int getStockLevel(java.lang.String arg0, java.lang.String arg1) {
        ws.ShareBrokerService_Service service = new ws.ShareBrokerService_Service();
        ws.ShareBrokerService port = service.getShareBrokerServicePort();
        return port.getStockLevel(arg0, arg1);
    }





    










    
}
