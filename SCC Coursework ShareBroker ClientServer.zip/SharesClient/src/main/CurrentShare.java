/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 *
 * @author Nayphilim
 */
public class CurrentShare {
    String CompanyName;
    String CompanySymbol;
    int AvailableShares;
    String Currency;
    double Value;
    XMLGregorianCalendar LastUpdated;
    
    public void setCompanyName(String companyName){
        CompanyName = companyName;
    }
    
    public void setCompanySymbol(String companySymbol){
        CompanySymbol = companySymbol;
    }
    
    public void setAvailableShares(int availableShares){
        AvailableShares = availableShares;
    }
    
    public void setCurrency(String currency){
        Currency = currency;
    }
    
    public void setValue(double value){
        Value = value;
    }
    
    public void setLastUpdated(XMLGregorianCalendar lastUpdated){
        LastUpdated = lastUpdated;
    }
    
    public String getCompanyName(){
        return CompanyName;
    }
    
    public String getCompanySymbol(){
        return CompanySymbol;
    }
    
    public int getAvailableShares(){
        return AvailableShares;
    }
    
    public String getCurrency(){
        return Currency;
    }
    
    public double getValue(){
        return Value;
    }
    
    public XMLGregorianCalendar getLastUpdated(){
        return LastUpdated;
    }
    
}
