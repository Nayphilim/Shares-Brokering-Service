/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DOCwebServices;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * REST Web Service
 *
 * @author Nayphilim
 */
@Path("/conversionRest")
@WebService()
public class ConversionRestResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ConversionRestResource
     */
    public ConversionRestResource() {
    }

    public void updateCurrencyRates() throws MalformedURLException, IOException, ParseException{
        URL url = new URL("https://api.exchangeratesapi.io/latest?base=GBP");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        JSONObject jsonData = new JSONObject();
        if(conn.getResponseCode() != 200){
            
        }
        else{
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inString = br.readLine();
        br.close();
        conn.disconnect();
            
        
        JSONParser jsonParser = new JSONParser();
        jsonData = (JSONObject) jsonParser.parse(inString);
        FileWriter writer = new FileWriter("D:\\Nayphilim\\Documents\\NetBeansProjects\\CurrencyConvertor\\currencyData.json");
        writer.write(jsonData.toJSONString());  
        writer.close();
        
        }

        
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getCurrencyRate(@QueryParam("currency")String currency) throws FileNotFoundException, IOException, ParseException{
        updateCurrencyRates();
        JSONParser jsonParser = new JSONParser();
        JSONObject returnJson = new JSONObject();
        Reader reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\CurrencyConvertor\\currencyData.json");
        JSONObject currencyRateFile = (JSONObject) jsonParser.parse(reader);
        JSONObject currencyList = (JSONObject) currencyRateFile.get("rates");
        String currencyRate = currencyList.get(currency).toString();
        double curRate = Double.parseDouble(currencyRate);
        
        returnJson.put(currency, currencyList.get(currency));
             

    return returnJson.toString();
    }
    
    public double getExchangeRateValue(String currency){
        try {
            String currencyRate = getCurrencyRate(currency);
            JSONParser jsonParser = new JSONParser();
            JSONObject jsonData = new JSONObject();
            String exchangeRates;
            double exchangeRateValue;
            URL url = new URL("http://localhost:8080/CurrencyConvertor/webresources/conversionRest?currency=" + currency);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            
            
            if(conn.getResponseCode() != 200){
                jsonData = (JSONObject) jsonParser.parse(currencyRate);
                exchangeRates = jsonData.get(currency).toString();
                exchangeRateValue = Double.parseDouble(exchangeRates);
                return exchangeRateValue;
            }
            else{
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inString = br.readLine();
                br.close();
                
                jsonData = (JSONObject) jsonParser.parse(inString);
                exchangeRates = jsonData.get(currency).toString();
                exchangeRateValue = Double.parseDouble(exchangeRates);
                return exchangeRateValue;
            }   
        } catch (MalformedURLException ex) {
            Logger.getLogger(ConversionRestResource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConversionRestResource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ConversionRestResource.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return 0;
}
}
