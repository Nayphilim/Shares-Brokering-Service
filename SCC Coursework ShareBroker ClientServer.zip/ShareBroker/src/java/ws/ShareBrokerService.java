/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import ShareDetails.CurrentShares;
import ShareDetails.Shares;
import ShareDetails.Shares.SharePrice;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.GregorianCalendar;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


/**
 *
 * @author Nayphilim
 */
@WebService(serviceName = "ShareBrokerService")
public class ShareBrokerService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getShareList")
    public List<Shares> getShareList() {
        ShareDetails.CurrentShares shareXML = new ShareDetails.CurrentShares();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(shareXML.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            shareXML = (CurrentShares) unmarshaller.unmarshal(new java.io.File("D:/Nayphilim/Documents/NetBeansProjects/ShareBroker/Current_Shares")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<Shares> currentShares = shareXML.getShareCollection();
        
        
        
    return currentShares;
    }
    
    public void completeTransaction(int shareNum, String companyName) throws IOException{
        List<Shares> postTranShares = getShareList();
        ShareDetails.CurrentShares shareXML = new ShareDetails.CurrentShares();
        Shares nextShare;
        Iterator itr = postTranShares.iterator();
        while(itr.hasNext()){
            nextShare = (Shares) itr.next();
            if(nextShare.getCompanyName().equals(companyName)){
                if(nextShare.getNumberOfAvailableShares() > shareNum){
                nextShare.setNumberOfAvailableShares(nextShare.getNumberOfAvailableShares()-shareNum);
                }
            }
        }
        shareXML.getShareCollection().addAll(postTranShares);
         try {            
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(shareXML.getClass().getPackage().getName());
            javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8"); //NOI18N
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            
            File shareStore = new File("D:/Nayphilim/Documents/NetBeansProjects/ShareBroker/Current_Shares");
                    
            marshaller.marshal(shareXML,shareStore);
            
            marshaller.marshal(shareXML, System.out);
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
    }
    
    public boolean validateUser(String username){
        Reader reader = null;
        try {
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject usersData = (JSONObject) usersJson.get("users");
            if(usersData.containsKey(username)){
                return true;
            }
              
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                reader.close();
            } catch (IOException ex) {
                Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    public String getUserShares(String username){
        try {
            Reader reader = null;
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject usersData =  (JSONObject) usersJson.get("users");
            String userShares = usersData.get(username).toString();
            return userShares;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public void addUserShares(String username, String companyName, int numShares, String currency, double value){
        try {
            Reader reader = null;
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject userData = (JSONObject) usersJson.get("users");
            JSONObject userShares = (JSONObject) userData.get(username);
            
            if(userShares.containsKey(companyName)){
                JSONObject existingShare = (JSONObject) userShares.get(companyName);
                int shares = Integer.parseInt(existingShare.get("numberShares").toString());
                int newShares = shares + numShares;
                JSONObject newShare = new JSONObject();
                newShare.put("numberShares", newShares);
                newShare.put("currency", currency);
                newShare.put("value", value);
                userShares.put(companyName, newShare);
                userData.put(username, userShares);
                usersJson.put("users", userData);
            }
            else{
                JSONObject newShare = new JSONObject();
                newShare.put("numberShares", numShares);
                newShare.put("currency", currency);
                newShare.put("value", value);
                userShares.put(companyName, newShare);
                userData.put(username, userShares);
                usersJson.put("users", userData);
            }
            
                FileWriter writer = new FileWriter("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
                writer.write(usersJson.toJSONString());  
                writer.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sellShares(String username, String companyName, int numShares, String currency, double value){
        try {
            Reader reader = null;
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject userData = (JSONObject) usersJson.get("users");
            JSONObject userShares = (JSONObject) userData.get(username);
            JSONObject companyShares = (JSONObject) userShares.get(companyName);
            int existingShares = Integer.parseInt(companyShares.get("numberShares").toString());
            if(existingShares > numShares){
                int newShares = existingShares - numShares;
                JSONObject newShare = new JSONObject();
                newShare.put("numberShares", newShares);
                newShare.put("currency", currency);
                newShare.put("value", value);
                userShares.put(companyName, newShare);
                userData.put(username, userShares);
                usersJson.put("users", userData);
            }
            else{
                userShares.remove(companyName);
                userData.put(username, userShares);
                usersJson.put("users", userData);
            }
            
            FileWriter writer = new FileWriter("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            writer.write(usersJson.toJSONString());  
            writer.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean hasStocks(String username, String companyName){
        try {
            Reader reader = null;
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject userData = (JSONObject) usersJson.get("users");
            JSONObject userShares = (JSONObject) userData.get(username);
            if(userShares.containsKey(companyName)){
                return true;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public int getStockLevel(String username, String companyName){
        try {
            Reader reader = null;
            JSONParser jsonParser = new JSONParser();
            reader = new FileReader("D:\\Nayphilim\\Documents\\NetBeansProjects\\ShareBroker\\users.json");
            JSONObject usersJson = (JSONObject) jsonParser.parse(reader);
            JSONObject userData = (JSONObject) usersJson.get("users");
            JSONObject userShares = (JSONObject) userData.get(username);
            JSONObject companyShares = (JSONObject) userShares.get(companyName);
            int existingShares = Integer.parseInt(companyShares.get("numberShares").toString());
            return existingShares;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ShareBrokerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
}
